#!/bin/bash
php composer.phar archive --format=zip